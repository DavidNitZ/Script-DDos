"""
Contains the networking code for `pyminecraft`.
"""
